# Programming-Basics-Book-PHP-BG
Textbook for the "Programming Basics" course @ SoftUni (PHP, Bulgarian)

This project is not yet started. It might happend some day...
